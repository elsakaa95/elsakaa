<?php
    $args = array(
        'post_type' => 'egypt_news',
        'posts_per_page' => -1,
    );
    $query = new WP_Query( $args );
    if ( $query->have_posts() ) :
?>

<div class="slider-custom-post-type">
    <ul class="slider-custom-post-type-slides">
        <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <li class="slider-custom-post-type-slide">
                <?php the_title(); ?>
                <?php the_post_thumbnail(); ?>
                <?php the_excerpt(); ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<?php
    endif;
    wp_reset_postdata();
?>

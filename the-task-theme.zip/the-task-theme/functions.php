<?php
require_once get_template_directory() . '/egypt-news.php';

function university_files(){
    wp_enqueue_script('main-university-js',get_theme_file_uri('/build/index.js'),array('jquery'),'1.0',true) ;
    wp_enqueue_style('font-awesome','//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i');
    wp_enqueue_style('university_main_styles',get_theme_file_uri( '/build/style-index.css' ));
    wp_enqueue_style('university_extra_styles',get_theme_file_uri( '/build/index.css' ));
    wp_enqueue_style('custom-google-fonts','//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
}


add_action( 'wp_enqueue_scripts','university_files');
function setPostViews($postID) {
    $countKey = 'post_views_count';
    $count = get_post_meta($postID, $countKey, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $countKey);
        add_post_meta($postID, $countKey, '0');
    }else{
        $count++;
        update_post_meta($postID, $countKey, $count);
    }
}
function custom_query_order($query) {
    if (!is_admin() && $query->is_main_query()) {
        $query->set('meta_key', 'post_views_count');
        $query->set('orderby', 'meta_value_num');
        $query->set('order', 'DESC');
    }
}
add_action('pre_get_posts', 'custom_query_order');
function set_post_view($postID) {
    set_post_views($postID);
}
add_action('wp_head', 'set_post_view');
function set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

function enqueue_custom_styles() {
    wp_register_style( 'custom-styles', get_template_directory_uri() . '/custom-styles.php' );
    wp_enqueue_style( 'custom-styles' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_custom_styles' );
function university_features(){
    register_nav_menu( 'headerMenuLocation' , 'Header Menu Locatiion' );
    register_nav_menu( 'footerLocationOne' , 'Footer Locatiion One' );
    register_nav_menu( 'footerLocationTwo' , 'Footer Locatiion Two' );
    add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme','university_features' );

function university_adjust_queries($query){
    if(!is_admin() And is_post_type_archive('program') AND is_main_query()){
        $query->set('orderby', 'title');
        $query->set('order','ASC');
        $query->set('post_per_page','-1');
    }
    if(!is_admin() AND is_post_type_archive('event') AND is_main_query()){
    $today = date('Ymd');
    $query->set('meta_key','event_date');
    $query->set('orderby','meta_value_num');
    $query->set('order','ASC');
    $query->set('meta_query',array(
        array(
          'key' => 'event_date',
          'compare' => '>=',
          'value' => $today,
          'type' => 'numeric'
        )
        ));
}
}
    add_action( 'pre_get_posts', 'university_adjust_queries' );
    add_theme_support('post-thumbnails');

?>
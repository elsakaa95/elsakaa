<!DOCTYPE html>
<html <?php language_attributes(  ) ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ) ?>" > 
    <meta name="viewport" content="width=device-width , initial-scale = 1" >
    <?php wp_head();?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
</head>
<body <?php body_class(  )?>>
<header class="site-header">
<nav class="navbar navbar-expand-lg bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">local</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Feature</a>
        </li>
      
      <li class="nav-item">
          <a class="nav-link" href="#">World/Middle East</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Business</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Science</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Culture</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Life Style</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Opinion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Gallery</a>
        </li>
        </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
    </header>

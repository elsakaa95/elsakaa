<?php
get_header();
?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/library/css/slick.css" />
<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/library/css/slick-theme.css" />

<div class="container-fluid">
	<div class="row">
		<?php
		$image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'single-post-thumbnail');
		$homepagePosts = new WP_Query(array(
			'post_type',
			'posts_per_page' => 1

		));
		while ($homepagePosts->have_posts()) {
			$homepagePosts->the_post(); ?>

			<div class="col-md-5" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 450px;">
				<div class="text">
					<h5 class="title1"><a href="<?php the_permalink() ?>"><?php the_category(); ?></a></h5>
					<p class="title1"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></p>
				</div>
			</div>
		<?php }
		wp_reset_postdata();
		?>
		<div class="col-md-3 first-section">
			<div class="row">

				<!-- // Define our WP Query Parameters -->
				<?php
				$the_query = new WP_Query(array('posts_per_page' => 1, 'offset' => 1));
				?>

				<!-- // Start our WP Query -->
				<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

					<!-- // Display the Post Title with Hyperlink -->
					<div class="col-md-12 first-pic" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>');    background-repeat: no-repeat;
   					 background-position: center center;
    				 background-size: cover;
    				 height: 222.5px;">
						<div class="text">
							<h5 class="title1"><a href="<?php the_permalink() ?>"><?php the_category(); ?></a></h5>
							<p class="post-content"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></p>
						</div>
					</div>
				<?php
				endwhile;
				wp_reset_postdata();
				?>
				</ul>
				</p>
			</div>
			<div class="row">

<!-- // Define our WP Query Parameters -->
<?php
$the_query = new WP_Query(array('posts_per_page' => 1, 'offset' => 2));
?>

<!-- // Start our WP Query -->
<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

	<!-- // Display the Post Title with Hyperlink -->
	<div class="col-md-12" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>');    background-repeat: no-repeat;
		background-position: center center;
	 background-size: cover;
	 height: 222.5px;">
		<div class="text">
			<h5 class="title1"><a href="<?php the_permalink() ?>"><?php the_category(); ?></a></h5>
			<p class="post-content"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></p>
		</div>
	</div>
<?php
endwhile;
wp_reset_postdata();
?>
	</div>
</div>
<div class="col-md-3">
	<h2>
		Heading
	</h2>
	<p>
		Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
	</p>
	<p>
		<a class="btn" href="#">View details »</a>
	</p>
</div>
</div>
</div>
<div class="slider_page_wrapper">
<hr class="divider">
	<h6 style="margin-left:40px;">EGYPT NEWS </h6>
	<?php
	$args_array = array(
		'posts_per_page' => -1,
		'post_type' => 'egyptviews',
		'post_status' => 'publish',
		'orderby' => 'post_type',
		'order' => 'DESC'
	);
	$get_egyptviews_posts = get_posts($args_array);
	if ($get_egyptviews_posts) {
		echo '<div class="custom_slider">';
		foreach ($get_egyptviews_posts as $post) :
			setup_postdata($post);
	?>
			<div class="post_wrapper" style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>');background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
	height:200px;margin-right:5px">
				<?php $fatured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'full') ?>
				<div class="right_section text"><a class="post-content" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

				</div>
			</div>
	<?php
		endforeach;
		wp_reset_postdata();
		echo '</div>';
	}
	?>
</div>
</div>
<div class="container-fluid" Style="margin-top:30px;">
	<div class="row">
		<div class="col-md-8">
		<hr class="divider">
			<h6 style="margin-left:20px;"> FEATURES </h6>
			
			<div class="last-section">
				<?php
				$image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'single-post-thumbnail');
				$homepagePosts = new WP_Query(array(
					'posts_per_page' => 2,
					'post_type' => 'egyptviews'

				));
				while ($homepagePosts->have_posts()) {
					$homepagePosts->the_post(); ?>

					<div class="col-md-6">
						<div style="background-image: url('<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 350px;">

							<div class="text">
								<h6 class="title1"><a href="<?php the_permalink() ?>"><?php echo get_post_type(); ?></a></h6>
								<p class="post-content"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></p>
							</div>
						</div>
					</div>
				<?php }
				wp_reset_postdata();
				?>
			</div>
		</div>
		<div class="col-md-4">
		<hr class="divider">
			<h6> TOP 5 STORIES </h6>
			<hr>
			<?php
			global $wp_query;
			$total_pages = $wp_query->max_num_pages;
			$current_page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
			$post_count = ($current_page-1) * get_query_var( 'posts_per_page' ) + 1;
			$posts = array();
			$args = array(
				'meta_key' => 'post_views_count',
				'posts_per_page' => 5,
				'orderby' => 'meta_value_num',
				'order' => 'DESC'
			);
			$query = new WP_Query($args);
			if ($query->have_posts()) {
				while ($query->have_posts()) {
					$query->the_post();
					$posts[] = get_post();?>
					<h4><span class="count"><?php echo $post_count;?></span><a href="<?php the_permalink() ?>"><?php  the_title(); ?></h4>					
					<?php $post_count++; ?>
					<hr>					
				<?}
				wp_reset_postdata();
			}
?>

		</div>
	</div>

</div>
</div>
</div>




<script src="//code.jquery.com/jquery-3.6.3.js"></script>
<script src="<?php echo get_template_directory_uri() ?>/library/js/slick.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$(' .custom_slider').slick({
			slidesToShow: 4,
			slidesToScroll: 1,
			autoplay: true,
			autoplayspeed: 2000,
		});
	});
</script>
<div>
    <?php wp_footer(); ?>
</div>
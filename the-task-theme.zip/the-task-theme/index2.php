<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package my_theme
 */

get_header();
?>
<section>
<div class="full-width-split__two">
        <div class="full-width-split__inner">
          <?php 
 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); 
  $homepagePosts = new WP_Query(array(
          'post_type',
          'posts_per_page' => 1

));
          while ($homepagePosts -> have_posts()) {
            $homepagePosts -> the_post(); ?>
 
           
            <div class="event-summary__content post-container left-section" style="background-image: url('<?php echo $image[0]; ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 450px;" >
    <div class="text">
              <h5 class="title1" ><a href="<?php the_permalink()?>"><?php the_category();?></a></h5>
              <p class="post-content"><?php the_title();?></p>
            </div>
          </div>
          <?php }wp_reset_postdata();
          ?>

  <div class="right-section">
  <div class="event-summary__content post-container right-post1" style="background-image: url('<?php echo $image[0]; ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 223px;" >
    <div class="text">
              <h5 class="title1" ><a href="<?php the_permalink()?>"><?php the_category();?></a></h5>
              <p class="post-content"><?php the_title();?></p>
            </div>
          </div>

  <div class="event-summary__content post-container right-post2" style="background-image: url('<?php echo $image[0]; ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 223px;" >
    <div class="text">
              <h5 class="title1" ><a href="<?php the_permalink()?>"><?php the_category();?></a></h5>
              <p class="post-content"><?php the_title();?></p>
            </div>
          </div>
        </div>
        <div class="event-summary__content post-container right-post3" style="background-image: url('<?php echo $image[0]; ?>');    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    height: 450px;" >
    <div class="text">
              <h5 class="title1" ><a href="<?php the_permalink()?>"><?php the_category();?></a></h5>
              <p class="post-content"><?php the_title();?></p>
            </div>
          </div>
</section>
<section>
  <h2 class="the-title">EGYPT NEWS </h2>
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="..." alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="..." alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="..." alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</section>
<section>
<h2 class="the-title"> FEATURES </h2>
  <div>
</div>
<div>
<h2 class="the-title">TOP 5 STORIES </h2>
<div></div>
</div>
</section>


<?php
get_footer();
?>

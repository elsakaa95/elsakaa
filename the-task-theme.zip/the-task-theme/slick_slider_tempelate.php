<?php 
get_header();
?>
<main class="wp-block-group">
    <div class="slider_page_wrapper">
        <h1>Show all Posts </h1>
    </div>
</main>
<?php get_footer();?>